import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-return',
  templateUrl: './return.component.html',
  styleUrls: ['./return.component.css']
})
export class ReturnComponent implements OnInit {

  copies={"Id":"","BookId":"","RackNo":"","Status":""}
  books={"Name":"","Author":"","Subject":"","Price":"","ISBN":""}


  payments={"Id":"","UserId":"","Amount":"","Type":"","Transactiontime":"","nextPaymentDue":""}
  issue={"Id":"","CopyId":"","MemberId":"","IssueDate":"","ReturnDueDate":"","ReturnDate":"","FineAmount":""}
    constructor(private route: ActivatedRoute,
    private router: Router,
    private service: DataService) { }
 
  ngOnInit() {
  }

  Search() {
    console.log(this.payments,this.copies,this.books,this.issue);
    let observableResult = this.service.SelectbyNo(this.payments);
    observableResult.subscribe((result) => {
      console.log(result);
      this.router.navigate(['/home']);
    });
  }

}
