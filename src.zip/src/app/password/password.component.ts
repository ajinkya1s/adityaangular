import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {

  emp={"Name":"","Email":"","Phone":"","Password":"","Role":""};
    constructor(private route: ActivatedRoute,
    private router: Router,
    private service: DataService) { }

  ngOnInit() {
    this.route.paramMap.subscribe((result) => {
      let No = result.get("No");
      let observableResult = this.service.SelectbyNo(No);
      observableResult.subscribe((data) => {
        console.log(data);
        this.emp = data[0];
      });
    });
  }

}
