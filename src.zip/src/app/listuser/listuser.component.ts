import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {

  emps:any;
  constructor(private service: DataService,private service1:AuthService,
    public router: Router ) { }

    ngOnInit() {
      let observableResult = this.service.Select();
        observableResult.subscribe((result)=>{
          console.log(result);
          this.emps=result;
        });
  
     
      this.emps=[
        {"Name":"aditya","Email":"adi@gmail.com","Phone":8898989890,"Password":"adi","Role":"librarian"},
        {"Name":"aditya2","Email":"adi2@gmail.com","Phone":8898989891,"Password":"adi2","Role":"librarian"}
      ];
  
    }

  
}
